﻿# $PSScriptRoot = 自動変数_実行した.ps1のあるディレクトリ
$buf = (Get-Date).ToString("yyyy.MM.dd-HH.mm.ss")
$Fname = $PSScriptRoot + "\img\" + $buf + ".png"
$Image = Get-Clipboard -Format Image
$Image.Save($Fname)
Set-Clipboard $Fname

