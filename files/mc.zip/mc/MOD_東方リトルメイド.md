# 東方リトルメイド

<img src="https://doron-san.github.io/img/2025.03.27-13.32.41.png" width="100">

↓前提MOD？
MCMultiPart
Patchouli
Obfuscate

マイクラバージョン1.12.1での動画が多かったのでしばらくやってみたが、Functionの補完がなかったり、マウスの感度が致命的だったりで中断。  
情報は少なそうだが、マイクラバージョン1.18.2でやってみることにした。

- [日誌](MOD_東方リトルメイド_日誌.md)
- [レシピ](MOD_東方リトルメイド_レシピ.md)
- [覚えやすい幻想卿](MOD_東方リトルメイド_覚えやすい幻想卿.md)

<font color="red">食べ物をメインかオフハンドにおけば好感度は大幅にあがり、健康も回復する。</font>

- 好感度とMaxにするとHPが20から80なった検証をしたのだが、1.12.1か1.18.2かを忘れた・・・・
  
  <img src="https://doron-san.github.io/img/2025.03.27-14.55.17.png" width="280">

- 1.18.2で好感度Maxテストしてみた
  
  - 好感度Max = 384
  - Max時のHP = 80(Default = 20)

- HPは金のリンゴで回復っていうらしいが、肉やパンでも充分回復してるっぽい。様子見で。

---




---

### リンク

- [Touhou Little Maidのダウンロードページ](https://www.curseforge.com/minecraft/mc-mods/touhou-little-maid)
  
  <img src="https://doron-san.github.io/img/2025.03.27-13.32.37.png" width="280">
  
  - [東方リトルメイド開発Wiki](http://page.cfpa.team/TouhouLittleMaid/)
    上記のダウンロードページのWikiから飛んだらあった！
    
    <img src="https://doron-san.github.io/img/2025.03.27-13.46.53.png" width="100">

- [メイドに仕事をさせる方法](https://ore-game.com/minecraft/post/touhou-maid/)

- [メイドを宝玉で強化](https://ore-game.com/minecraft/post/touhou-bauble/)

1.12.2

- [[MOD紹介]東方×リトルメイド+αなMOD](https://www.youtube.com/watch?v=d9_ghTZkZys)
- [東方キャラ勢ぞろいのかわいいMODを紹介！](https://www.youtube.com/watch?v=xKowWaJCIYA)

---