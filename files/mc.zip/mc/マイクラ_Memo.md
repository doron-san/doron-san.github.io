﻿```
/tellraw @p {"text":"こんにちは"}
/tellraw @p {"text":"こんにちは","color":"red"}
```

---

半径2ブロック以内に羊がいる場合に関数を実行する: 

```
execute if entity @e[type=sheep,distance=..2] run function custom:example/test
```

---

実行者がプレイヤーでない場合に関数を実行する

```
execute unless entity @s[type=player] run function custom:example/test
```

[マイクラのexecuteについて備忘録](https://keiduki.hatenablog.com/entry/2020/04/27/230935)

[setblockコマンド](https://natsumake.com/set-block/#1_setblock%E3%82%B3%E3%83%9E%E3%83%B3%E3%83%89)

[装飾ツール？]([https://mcstacker.net/](https://mcstacker.net/))

[【マイクラJava版】「give」コマンドで使うアイテムID一覧](https://tech-teacher.jp/kids-blog/command-give-id-java/)

[【Minecraft】functionコマンドで拠点を瞬時に建築する](https://science-log.com/%E9%9B%91%E8%A8%98top%E3%83%9A%E3%83%BC%E3%82%B8/%E3%80%90minecraft%E3%80%91function%E3%82%B3%E3%83%9E%E3%83%B3%E3%83%89%E3%81%A7%E6%8B%A0%E7%82%B9%E3%82%92%E7%9E%AC%E6%99%82%E3%81%AB%E5%BB%BA%E7%AF%89%E3%81%99%E3%82%8B/)

[スライムファインダー](https://www.chunkbase.com/apps/slime-finder#seed=-4907945317356789317&platform=java&x=0&z=0&zoom=1)

砂漠バイオーム：`/locate biome desert`
荒野バイオーム：`/locate biome mesa`

[レール無限装置の作り方を2種類紹介【Java版限定】](https://tech-teacher.jp/kids-blog/minecraft-rail-device/)

[【JAVA版コマンドブロックで遅延付きのループをさせる】](https://www.youtube.com/watch?v=opOzNe7FBmM)

- スコアボードの追加。1度の入力で永遠に動作するっぽい（チャットでOK）
  `/scoreboard objectiv`e`s add timer dummy`

- ちゃんとできてるか確認（チャットでOK）
  `/scoreboard objectives list`

- コマンドブロック① リピート  無条件  動力必要

- コマンドブロック② チェーン  無条件  常時実行

- コマンドブロック③ チェーン  条件付  常時実行

コマンドブロック①  毎1/20秒ごとに1カウント増加
scoreboard players add timer timer 1

コマンドブロック②  20は遅延のティック数20=1秒。runの後の書き換えで実行するコマンドが変えられる
execute if score timer timer matches 20 run say こんにちは

コマンドブロック③  タイマーのリセット。ループではなく1回の遅延にする場合は③は不要
scoreboard players set timer timer 0

コマンド実行ログを消す（チャットでOK）
/gamerule commandBlockOutput false

【デバッグ】
タイマーの手動リセット（チャットOK）
/scoreboard players set timer timer 0

コマンドブロックの報告を見えるように戻す（チャットOK）
/gamerule commandBlockOutput true

------------------------------------------------------

草原の村を探す
/locate structure minecraft:village_plains
TPコマンドで表示された座標に飛ぶ

看板文字の装飾->2025.08.19現在成功したことがない。バージョン依存か？
                              輝くイカ墨で看板が読みやすくなったのでそれで代用中
※§は「セクション＋変換」で書ける・・・はず
§0 黒          §a 緑         /§k 読めないようにする
§1 濃い青      §b 水色       /§l 太くする
§2 濃い緑      §c 赤         /§o イタリック体
§3 濃い水色    §d ピンク     /§r 書式をリセットする
§4 濃い赤色    §e 黄色
§5 濃い紫      §f 白色
§6 金色
§7 灰色
§8 濃い灰色
§9 青

@a    ワールドにいる全てのプレイヤー
@e    すべてのエンティティ
@p    コマンドの実行場所から最も近くにいるプレイヤー1人
@r    ワールドにいるプレイヤーの中からランダムに1人
@s    コマンドを実行したエンティティ
