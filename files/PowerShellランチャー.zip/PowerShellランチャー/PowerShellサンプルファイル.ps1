﻿
using namespace System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms

$Form1 = New-Object Form
$Form1.Size = "400, 250"

$Label1 = New-Object Label
$Label1.Text = "これは「PowerShellサンプルファイル」です。"
$Label1.Location = "10, 10"
$Label1.Size = "500, 20"
$Form1.Controls.Add($Label1)

$Form1.ShowDialog()

