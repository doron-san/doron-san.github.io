﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ==========================================================
# 💡 ユーザー設定エリア
# 実行する .ps1 ファイルが格納されているフォルダを指定します。
# ----------------------------------------------------------
$ScriptDirectory = $PSScriptRoot  # "C:\Temp"
# $PSScriptRoot:
# 自動変数。現在実行中のスクリプトのディレクトリの絶対パスを保持している。
# ==========================================================

# ターミナル表示の状態を管理するグローバル変数（初期値は非表示）
$ShowTerminal = $false

# フォームの設定
$Form = New-Object System.Windows.Forms.Form
$Form.Text = "PowerShell スクリプトランチャー (実用最終版)"
$Form.Size = New-Object System.Drawing.Size(400, 300)
$Form.StartPosition = "CenterScreen"
$Form.MaximumSize = $Form.Size
$Form.MinimumSize = $Form.Size


# ターミナル表示切り替え用チェックボックスの設定
$CheckBox = New-Object System.Windows.Forms.CheckBox
$CheckBox.Text = "ターミナル"
$CheckBox.Location = New-Object System.Drawing.Point(10, 10) # フォームの左上に配置
$CheckBox.Checked = $ShowTerminal # 初期状態を反映

# チェックボックスの状態が変更されたときのイベントハンドラ
$CheckBox.Add_CheckedChanged({
    # グローバル変数 $ShowTerminal をチェックボックスの状態に同期させる
    $global:ShowTerminal = $this.Checked

    # ログに出力
    if ($global:ShowTerminal) {
        Write-Host "--- ターミナル表示: ON (実行時に表示されます)" -ForegroundColor Green
    } else {
        Write-Host "--- ターミナル表示: OFF (実行時に非表示になります)" -ForegroundColor Yellow
    }
})

$Form.Controls.Add($CheckBox) # フォームにチェックボックスを追加


# レイアウトパネルの設定 (ボタンはチェックボックスの下に配置するためY座標を調整)
$FlowLayoutPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$FlowLayoutPanel.Dock = "None"
$FlowLayoutPanel.AutoScroll = $true

# ボタンを縦並びで配置
$FlowLayoutPanel.FlowDirection = "TopDown"

$Form.Controls.Add($FlowLayoutPanel)


# スクリプト実行関数（バッチファイルを経由する方式）
function Execute-Script {
    param(
        [Parameter(Mandatory=$true)]
        [string]$ScriptPath
    )

    # 実行時のウィンドウ表示スタイルを決定
    # $global:ShowTerminal が $true なら Normal、 $false なら Hidden
    if ($global:ShowTerminal) {
        $WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Normal
        $CreateNoWindow = $false
        $DisplayStatus = "表示"
    } else {
        $WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
        $CreateNoWindow = $true
        $DisplayStatus = "非表示"
    }

    try {
        # 1. 起動用のバッチファイルの内容を作成
        $BatchContent = "@echo off`r`npowershell.exe -ExecutionPolicy Bypass -File `"$ScriptPath`""

        # 2. 一時フォルダにバッチファイルのパスを作成
        $TempBatchPath = Join-Path $env:TEMP ("launcher_" + [Guid]::NewGuid().ToString() + ".bat")

        # 3. バッチファイルを保存 (Defaultエンコーディング = ANSI相当)
        Set-Content -Path $TempBatchPath -Value $BatchContent -Encoding Default

        # 4. バッチファイルを指定の表示スタイルで実行 (System.Diagnostics.Processを使用)
        $ProcessInfo = New-Object System.Diagnostics.ProcessStartInfo
        $ProcessInfo.FileName = $TempBatchPath
        $ProcessInfo.WindowStyle = $WindowStyle # ここが切り替えポイント
        $ProcessInfo.CreateNoWindow = $CreateNoWindow # ここも切り替えポイント
        $ProcessInfo.UseShellExecute = $true

        [System.Diagnostics.Process]::Start($ProcessInfo)

        # 実行ログを元のPowerShellコンソールに出力
        $ScriptName = [System.IO.Path]::GetFileNameWithoutExtension($ScriptPath)
        Write-Host "--- $($ScriptName) を $($DisplayStatus)実行しました。 $(Get-Date -Format 'HH:mm:ss')"
    }
    catch {
        Write-Host "--- 実行エラー: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# ボタンの動的生成とレイアウト調整
function Create-ScriptButtons {
    $FlowLayoutPanel.Controls.Clear()
    
    # 1. フォルダ内の全 ps1 ファイルを取得
    $Scripts = Get-ChildItem -Path $ScriptDirectory -Filter "*.ps1" -ErrorAction SilentlyContinue

    # ==========================================================
    # 💡 修正ポイント: 自分自身のスクリプトを除外する処理
    # ==========================================================
    # $PSCommandPath は現在実行中のこのスクリプト自身のフルパスです。
    if ($Scripts) {
        $CurrentScriptPath = $PSCommandPath
        # FullName（ファイルのフルパス）が自分自身と一致しないものだけを残す
        $Scripts = $Scripts | Where-Object { $_.FullName -ne $CurrentScriptPath }
    }
    # ==========================================================

    # 自分以外にスクリプトがない、またはフォルダが空の場合の処理
    if (-not $Scripts) {
        $Label = New-Object System.Windows.Forms.Label
        $Label.Text = "実行可能な他の .ps1 ファイルが見つかりません。"
        $Label.AutoSize = $true
        $FlowLayoutPanel.Controls.Add($Label)
        return
    }

    # 各ボタンに適用する固定幅
    $ButtonWidth = 330
    $ButtonHeight = 30

    foreach ($Script in $Scripts) {
        $Button = New-Object System.Windows.Forms.Button
        $Button.Text = $Script.BaseName
        $Button.Width = $ButtonWidth
        $Button.Height = $ButtonHeight

        $Button | Add-Member -MemberType NoteProperty -Name "ScriptPath" -Value $Script.FullName

        $Button.Add_Click({
            $PathToExecute = $this.ScriptPath
            Execute-Script -ScriptPath $PathToExecute
        })

        $FlowLayoutPanel.Controls.Add($Button)
    }

    # ***** レイアウト調整: FlowLayoutPanel 自体を中央に配置 *****

    # 1. FlowLayoutPanel のサイズを、ボタン群に合わせて設定
    $FlowLayoutPanel.Width = $ButtonWidth + 40 # ボタン幅 + 左右のパディング

    # 2. FlowLayoutPanel の高さを、ボタンの数に合わせて設定 (ここでは最大フォーム高に合わせる)
    $FlowLayoutPanel.Height = $Form.Height - 50 # チェックボックスの高さ分、フォーム高から引く

    # 3. FlowLayoutPanel の X 座標を計算し、フォームの中央に配置
    $CenterPointX = ($Form.Width - $FlowLayoutPanel.Width) / 2 + 10

    # 4. FlowLayoutPanel の Y 座標 (上からの位置) を設定 (チェックボックスの下に配置)
    $FlowLayoutPanel.Location = New-Object System.Drawing.Point($CenterPointX, 40)
}

# フォーム表示前にボタンを生成
Create-ScriptButtons

# フォームの表示
[void]$Form.ShowDialog()